module.exports = {
    mongoDbUrl: 'mongodb://abdo:Abdo1379@ds339968.mlab.com:39968/cms'
};
